import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class OMDbApiClient {
    private static final String BASE_URL = "http://www.omdbapi.com/";
    private static final String API_KEY = "58ac21a2";

    public static String searchMovieByTitle(String title) {
        OkHttpClient client = new OkHttpClient();

        String url = BASE_URL + "?apikey=" + API_KEY + "&t=" + title;
        Request request = new Request.Builder()
                .url(url)
                .build();

        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                return response.body().string();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;

}

