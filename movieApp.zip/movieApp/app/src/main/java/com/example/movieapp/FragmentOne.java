package com.example.movieapp;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class FragmentOne extends Fragment {
    private EditText movieTitleEditText;
    private Button searchButton;
    private Button favoriteButton;

    private FirebaseUser currentUser;
    private FirebaseFirestore db;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_one, container, false);

        movieTitleEditText = rootView.findViewById(R.id.movieTitleEditText);
        searchButton = rootView.findViewById(R.id.searchButton);
        favoriteButton = rootView.findViewById(R.id.favoriteButton);

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        db = FirebaseFirestore.getInstance();

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = movieTitleEditText.getText().toString();
                new OMDbSearchTask().execute(title);
            }
        });

        return rootView;
    }

    private class OMDbSearchTask extends AsyncTask<String, Void, String>
    {
        @Override
        protected String doInBackground(String... strings) {
            String title = strings[0];
            try {
                return OMDbApiClient.searchMovieByTitle(title);
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (result != null) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    String title = jsonObject.getString("Title");
                    String year = jsonObject.getString("Year");
                    String plot = jsonObject.getString("Plot");


                    TextView titleTextView = getView().findViewById(R.id.movieTitleTextView1);
                    TextView yearTextView = getView().findViewById(R.id.movieYearTextView2);
                    TextView plotTextView = getView().findViewById(R.id.moviePlotTextView3);

                    titleTextView.setText(title);
                    yearTextView.setText(year);
                    plotTextView.setText(plot);

                    favoriteButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (currentUser != null) {
                                saveFavoriteMovie(title, year, plot);
                                Toast.makeText(getContext(), "Movie favorited!", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getContext(), "Please sign in to favorite movies.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        private void saveFavoriteMovie(String title, String year, String plot) {
            CollectionReference favoritesRef = db.collection("favorites");
            Map<String, Object> movieData = new HashMap<>();
            movieData.put("userId", currentUser.getUid());
            movieData.put("title", title);
            movieData.put("year", year);
            movieData.put("plot", plot);

            favoritesRef.add(movieData)
                    .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                        @Override
                        public void onComplete(@NonNull Task<DocumentReference> task) {
                            if (task.isSuccessful()) {

                            } else {

                            }
                        }
                    });
        }
    }
}






