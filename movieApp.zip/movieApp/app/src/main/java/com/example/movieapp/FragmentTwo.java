package com.example.movieapp;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class FragmentTwo extends Fragment {
    private TextView favoriteMoviesTextView;

    private FirebaseUser currentUser;
    private FirebaseFirestore db;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_two, container, false);

        favoriteMoviesTextView = rootView.findViewById(R.id.favoriteMoviesTextView);

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        db = FirebaseFirestore.getInstance();

        if (currentUser != null) {
            loadFavoriteMovies();
        }

        return rootView;
    }

    private void loadFavoriteMovies() {
        CollectionReference favoritesRef = db.collection("favorites");
        favoritesRef.whereEqualTo("userId", currentUser.getUid())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            List<String> favoriteMovies = new ArrayList<>();
                            for (DocumentSnapshot document : task.getResult()) {
                                String title = document.getString("title");
                                String year = document.getString("year");
                                favoriteMovies.add(title + " (" + year + ")");
                            }
                            updateFavoriteMoviesTextView(favoriteMovies);
                        } else {

                        }
                    }
                });
    }

    private void updateFavoriteMoviesTextView(List<String> favoriteMovies) {
        StringBuilder stringBuilder = new StringBuilder();
        for (String movie : favoriteMovies) {
            stringBuilder.append(movie).append("\n\n");
        }
        favoriteMoviesTextView.setText(stringBuilder.toString());
    }
}







